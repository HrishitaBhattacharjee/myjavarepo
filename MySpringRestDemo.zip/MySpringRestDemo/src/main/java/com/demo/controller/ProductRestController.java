package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.service.ProductService;
import com.deno.bean.Product;

@RestController
public class ProductRestController {
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/products",produces="application/json")//MIME type
	public List<Product> getAllProduct(){
		return productService.getAllProduct();
	}

}
