package com.demo.comparator;

import java.util.Comparator;

import com.demo.bean.Product;
import com.demo.bean.;

//To compare electronics
public class MyQuantityComparator3 implements Comparator<Product>{

	@Override
	public int compare(Product ob1, Productob2) {
		System.out.println("in compare method");
		
		if(((Electronics)ob1).getItemQuantity()<((Electronics)ob2).getItemQuantity()){
			return -1;
		}
		else if(((Electronics)ob1).getItemQuantity()==((Electronics)ob2).getItemQuantity()) {
		    return 0;	
		}
		else {
			return 1;
		}
		
	}