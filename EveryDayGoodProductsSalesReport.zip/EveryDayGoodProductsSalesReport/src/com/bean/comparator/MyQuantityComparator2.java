package com.demo.comparator;

import java.util.Comparator;

import com.demo.bean.Product;
import com.demo.bean.;

//To compare apparels
public class MyQuantityComparator2 implements Comparator<Product>{

	@Override
	public int compare(Product ob1, Productob2) {
		System.out.println("in compare method");
		
		if(((Apparel)ob1).getItemQuantity()<((Apparel)ob2).getItemQuantity()){
			return -1;
		}
		else if(((Apparel)ob1).getItemQuantity()==((Apparel)ob2).getItemQuantity()) {
		    return 0;	
		}
		else {
			return 1;
		}
		
	}