package com.bean.comparator;

public class MyQuantityComparator1 {

}
