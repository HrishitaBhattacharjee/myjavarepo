package com.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.bean.Account;
import com.demo.bean.*;

import com.demo.bean.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	static {
		sc=new Scanner(System.in);
		sdf=new SimpleDateFormat("dd/mm/yyyy");
	}
   static Scanner sc;
   static SimpleDateFormat sdf;
   public ProductServiceImpl() {
	  this.productDao=new ProductDaoImpl();
    }

private ProductDao productDao;
   //To add product 
	@Override
	public boolean addProduct(int type) throws InvalidTypeException {
		Date dateOfManufacture;
		Date dateOfExpiry;
		System.out.println("Enter the item code");
		int itemCode=sc.nextInt();
		System.out.println("Enter the item name");
		String itemName=sc.next();
		System.out.println("Enter the unit price");
		double unitPrice=sc.nextDouble();
		System.out.println("Enter the quantity");
		int quantity=sc.nextInt();
		//Type 1 is food items
		if(type==1) {
			System.out.println("Enter the date of manufacture");
			//Date of manufacture
			String dt1=sc.next();
			System.out.println("Enter the date of expiry");
			//Date of expiry
			String dt2=sc.next();
			try {
				dateOfManufacture=sdf.parse(dt1);
				dateOfExpiry=sdf.parse(dt2);
				
			}catch(ParseException e) {
				e.printStackTrace();
			}
			System.out.println("Vegeterian?Yes/No");
			String vegeterian=sc.next();
			Product p=new FoodItems(itemCode,itemName,unitPrice,quantity,dateOfManufacture,dateOfExpiry,vegeterian);
			
			return productDao.addProduct(p,type);
		}
		
		//Type 2 is apparels
		else if(type==2) {
			System.out.println("Enter the size");
			String size=sc.next();
			System.out.println("Enter the material");
			String material=sc.next();
			Product p=new Apparel(itemCode,itemName,unitPrice,quantity,size,material);
			
			return productDao.addProduct(p,type);
			
		}
		
		//Type 3 is electronics
		else if(type==3) {
			System.out.println("Enter warranty in months");
			String warranty=sc.next();
			Product p=new Electronics(itemCode,itemName,unitPrice,quantity,warranty);
			return productDao.addProduct(p,type);
		}
		throw new InvalidTypeException("Type entered is invalid");
		
	}
	//get product list from Dao layer
	@Override
	public List<Product> getProductList(String type) {
		return productDao.getAllProduct(type);
	}
	
	
	
}