package com.demo.bean;
import java.io.Serializable;

abstract public class Product {
	
	//Instance Variables
	private int itemCode;
	private String itemName;
	private double unitPrice;
	private int itemQuantity;
	
	//Default Constructor
	public Product() {
		itemCode=0;
		itemName=null;
		unitPrice=0.0;
		itemQuantity=0;
	}
	
	//Parameterized Constructor
	public Product(int itemCode, String itemName, double unitPrice, int itemQuantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.itemQuantity = itemQuantity;
	}
	
	//Getters & Setters
	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getItemQuantity() {
		return itemQuantity;
	}

	

	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	
	

	
	@Override
	public boolean equals(Object obj) {
		
    	if(this.itemCode==((Product)obj).itemCode)
    		return true;
    	else 
    		return false;
	}

	//To print the object
	@Override
	public String toString() {
		return "Product [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", itemQuantity=" + itemQuantity + "]";
	}
}
	
	
	
	
