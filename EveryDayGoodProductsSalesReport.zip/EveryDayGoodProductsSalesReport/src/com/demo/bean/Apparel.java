package com.demo.bean;

public class Apparel extends Product{
	
	//Instance Variables
	private String apparelSize;
	private String apparelMaterial;
	
	//Default Constructor
	public Apparel() {
		super();
		apparelSize=null;
		apparelMaterial=null;
	}

	//Parameterized Constructor
	public Apparel(int itemCode, String itemName, double unitPrice, int itemQuantity,String apparelSize, String apparelMaterial) {
		super(itemCode,itemName,unitPrice,itemQuantity);
		this.apparelSize = apparelSize;
		this.apparelMaterial = apparelMaterial;
	}
	
	
	//Getters & Setters
	public String getApparelSize() {
		return apparelSize;
	}

	public void setApparelSize(String apparelSize) {
		this.apparelSize = apparelSize;
	}

	public String getApparelMaterial() {
		return apparelMaterial;
	}

	public void setApparelMaterial(String apparelMaterial) {
		this.apparelMaterial = apparelMaterial;
	}
	
	//To print the Apparel object
	@Override
	public String toString() {
		return super.toString()+"Apparel [apparelSize=" + apparelSize + ", apparelMaterial=" + apparelMaterial + "]";
	}
	
	
	
	
	
	

}
