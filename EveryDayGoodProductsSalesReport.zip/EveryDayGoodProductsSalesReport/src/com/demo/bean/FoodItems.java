package com.demo.bean;

import java.util.Date;

public class FoodItems extends Product {
	
	//Instance Variables
	private Date dateOfManufacture;
	private Date dateOfExpiry;
	private String vegetarian;
	
	//Default Constructor
	public FoodItems() {
		super();
		dateOfManufacture=null;
		dateOfExpiry=null;
		vegetarian=null;
	}
	
	//Parameterized Constructor
	public FoodItems(int itemCode, String itemName, double unitPrice, int itemQuantity,Date dateOfManufacture, Date dateOfExpiry, String vegetarian) {
		super(itemCode,itemName,unitPrice,itemQuantity);
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.vegetarian = vegetarian;
	}

	//Getters & Setters
	public Date getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(Date dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public String isVegetarian() {
		return vegetarian;
	}

	public void setVegetarian(String vegetarian) {
		this.vegetarian = vegetarian;
	}
	
	//To print the FoodItems object
	@Override
	public String toString() {
		return super.toString()+ "FoodItems [dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", vegetarian="
				+ vegetarian + "]";
	}
	
	
	
	
	
	

}
