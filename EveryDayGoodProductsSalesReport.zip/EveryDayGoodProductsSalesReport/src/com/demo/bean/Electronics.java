package com.demo.bean;

public class Electronics extends Product{
	//Instance Variable
	private String warranty;
	
	//Default Constructor
	public Electronics() {
		super();
		warranty=null;
	}
	
	//Parameterised Constructor
	public Electronics(int itemCode, String itemName, double unitPrice, int itemQuantity,String warranty) {
		super(itemCode,itemName,unitPrice,itemQuantity);
		this.warranty = warranty;
	}
	
	//Getter & Setter
	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	
	//To print Electronics object
	@Override
	public String toString() {
		return super.toString()+"Electronics [warranty=" + warranty + "]";
	}
	
	
	
	
	
	
	

}
