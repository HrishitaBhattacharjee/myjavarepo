package com.demo.exception;

//Exception for invalid type
public class InvalidTypeException extends Exception {
	public InvalidTypeException(String msg) {
		super(msg);
	}

}
