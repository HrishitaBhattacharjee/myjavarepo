package com.demo.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.demo.bean.Employee;
import com.demo.bean.Product;
import com.demo.bean.SalariedEmp;
import com.demo.comparator.MySalaryComparator;
import com.demo.exception.EmployeeNotFoundException;
import com.demo.comparator.*;
public class ProductDaoImpl implements ProductDao{
	
	 static List<Product> plist1;
	 static List<Product> plist2;
	 static List<Product> plist3;
	 static {
		 
		 plist1=new ArrayList<>();
		 plist2=new ArrayList<>();
		 plist3=new ArrayList<>();
		 
	 }
	 
	 
	 public void addProduct(Product p,int type)throws InvalidTypeException {
			if(type==1) {
				plist1.add(p);
				
			}
			else if(type==2) {
				plist2.add(p);
			}
			else if(type==3){
				plist3.add(p);
			}
			
		}
	 
	 //To sort the products of different types according to quantities
	 public List<Employee> sortData(int type) {
		 	if(type==1) {
		 		Collections.sort(plist1, new MyQuantityComparator1());
		 		return plist1;
		 	}
		 	else if(type==2) {
		 		Collections.sort(plist2, new MyQuantityComparator2());
		 		return plist2;
		 	}
		 	else if(type==3) {
		 		Collections.sort(plist3, new MyQuantityComparator3());
		 		return plist3;
		 	}
		 	
		}

	

}