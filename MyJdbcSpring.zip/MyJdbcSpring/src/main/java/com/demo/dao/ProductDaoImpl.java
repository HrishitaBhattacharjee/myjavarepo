package com.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.service.ProductService;
import com.deno.bean.Product;

@Repository
public class ProductDaoImpl implements ProductDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public void saveProduct(Product p) {
		jdbcTemplate.update("insert into product1(pid,pname,quantity) values(?,?,?)",new Object[]{p.getProductId(),p.getProductName(),p.getQuantity()});
		
	}
	public List<Product> findAll() {
		/*List<Product> plist=jdbcTemplate.query("select *from product1", new RowMapper<Product>() {

			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
				Product p=new Product();
				p.setProductId(rs.getInt(1));
				p.setProductName(rs.getString(2));
				p.setQuantity(rs.getInt(3));
				return p;
			}
			
		}));
		return plist;*/
		List<Product> plist=jdbcTemplate.query("select *from product1", (ResultSet rs,int rowNum)-> {

			
				Product p=new Product();
				p.setProductId(rs.getInt(1));
				p.setProductName(rs.getString(2));
				p.setQuantity(rs.getInt(3));
				return p;
			
			
		});
		return plist;
	}
	@Override
	public int deleteProduct(int id) {
		return jdbcTemplate.update("delete from product1 where pid=?",new Object[] {id});
		
	}
	@Override
	public Product findById(int id) {
		String sql="select * from product1 where pid=?";
		RowMapper<Product> r=(ResultSet rs,int numr)->{
			Product p=new Product();
			p.setProductId(rs.getInt(1));
			p.setProductName(rs.getString(2));
			p.setQuantity(rs.getInt(3));
			return p;
		};
		//new BeanPropertyRowMapper<>()
		return  jdbcTemplate.queryForObject(sql, new Object[] {id},r);
		/*jdbcTemplate.query("select * from pid=?", new Object[]{id},(ResultSet rs,int numr)->
			Product p=new Product();
			p.setProductId(rs.getInt(1));
			p.setProductName(rs.getString(2));
			p.setQuantity(rs.getInt(3));
			return p;
	});
		return plist.get(0);*/
		
	}
	@Override
	public int updateProduct(int id, int qty) {
		return jdbcTemplate.update("update product1 set quantity=? where pid=?",new Object[] {qty,id});
		
	}

}
