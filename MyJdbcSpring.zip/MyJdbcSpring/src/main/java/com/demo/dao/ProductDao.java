package com.demo.dao;

import java.util.List;

import com.demo.service.ProductService;
import com.deno.bean.Product;

public interface ProductDao {

	void saveProduct(Product p);

	List<Product> findAll();

	int deleteProduct(int id);

	Product findById(int id);

	int updateProduct(int id, int qty);

}
