package com.demo.test;

import java.util.Scanner;

import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;
import com.demo.service.ProductService;
import com.deno.bean.Product;
//Cant autowire because bean of main class is not made
public class TestCrudeDemo {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcconfig.xml");
		Scanner sc=new Scanner(System.in);
		int choice=0;
		ProductService productService=(ProductService) context.getBean("productServiceImpl");
		do {
			
			System.out.println("1.Add Product\n2.Display All\n3.Delete Product\n4.Update Product\n5.Display By Id\n6.exit");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				productService.addProduct();
				break;
			case 2:
				List<Product> plist=productService.getAllProduct();
				plist.forEach(System.out::println);
				break;
			case 3:
				System.out.println("Enter the product id");
				int id=sc.nextInt();
			    int n=productService.deleteProduct(id);
				if(n>0) {
					System.out.println("Product deleted");
				}
				else {
					System.out.println("Product not found");
				}
				break;
			case 4:
				System.out.println("Enter the product id");
				id=sc.nextInt();
				System.out.println("Enter the quantity");
				int qty=sc.nextInt();
				n=productService.updateProduct(id,qty);
				if(n>0) {
					System.out.println("Product updated");
				}
				else {
					System.out.println("Product not found");
				}
				break;
			case 5:
				System.out.println("Enter product id");
				id=sc.nextInt();
				Product p=productService.getProductById(id);
				if(p!=null) {
					System.out.println(p);
				}
				else {
					System.out.println("Product not found");
				}
				break;
			case 6:
				System.exit(0);
				break;
			}
			}while(choice!=6);
		
		

	}

}
