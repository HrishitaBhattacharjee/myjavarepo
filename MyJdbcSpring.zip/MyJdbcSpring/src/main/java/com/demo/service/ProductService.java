package com.demo.service;

import java.util.List;

import com.deno.bean.Product;

public interface ProductService {

	void addProduct();

	List<Product> getAllProduct();

	int deleteProduct(int id);

	Product getProductById(int id);

	int updateProduct(int id, int qty);

}
