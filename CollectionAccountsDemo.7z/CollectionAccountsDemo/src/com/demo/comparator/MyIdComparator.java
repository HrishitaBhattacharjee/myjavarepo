package com.demo.comparator;

import java.util.Comparator;

import com.demo.bean.*;

public class MyIdComparator implements Comparator<Account> {

	@Override
	public int compare(Account a1, Account a2) {
		if(((Account)a1).getAccId()<((Account)a2).getAccId()){
			return -1;
		}
		else if(((Account)a1).getAccId()==((Account)a2).getAccId()) {
		    return 0;	
		}
		else {
			return 1;
		}
		
	}

}
