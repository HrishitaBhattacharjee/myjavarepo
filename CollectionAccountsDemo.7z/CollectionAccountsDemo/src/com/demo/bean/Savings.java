package com.demo.bean;

public class Savings extends Account {
	
	//Instance Variables
	private final int iRate=2;
	private String checkBookNo;
	
	//Default Constructor
	public Savings() {
		super();
		checkBookNo=null;
	}
	
	//Parameterized Constructor
	public Savings(String accName, int accPin, double accBalance,String checkBookNo) {
		super(accName,accPin,accBalance);
		
		this.checkBookNo = checkBookNo;
	}
	
	public Savings(int id) {
		super(id);
	}
	//To withdraw amount
	@Override
	public double withdraw(double amount) {
		if((accBalance-10000)>=amount) {
			accBalance=accBalance-amount;
		}
		return accBalance;
	}
	
	//To calculate interest
	@Override
	public double calInterest() {
		double interest=0.0;
		if(accBalance>=50000) {
			interest=((accBalance*iRate)+(0.02*accBalance));
		}
		else {
			interest=accBalance*iRate;
		}
		return interest;
	}
	
	//To display object
	@Override
	public String toString() {
		return super.toString()+"Savings [checkBookNo=" + checkBookNo + "]";
	}	
	
}

