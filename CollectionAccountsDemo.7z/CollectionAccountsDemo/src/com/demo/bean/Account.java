package com.demo.bean;

abstract public class Account {
	//static block to assign count
	static {
		cnt=0;
	}
	
	//Instance Variables
	private static int cnt=0;
	private int accId;
	private String accName;
	private int accPin;
	protected double accBalance;
	
	
	//Default Constructor
	public Account() {
		this.accId=++cnt;
		this.accName=null;
		this.accPin=0;
		this.accBalance=0.0;
	}



	//Parameterized Constructor
	public Account(String accName, int accPin, double accBalance) {
		super();
		this.accId = ++cnt;
		this.accName = accName;
		this.accPin = accPin;
		this.accBalance = accBalance;
		getAccId();
		
	}


	//Getters and Setters
	public int getAccId() {
		return accId;
	}



	/*public void setAccId(int accId) {
		this.accId = accId;
	}*/



	public String getAccName() {
		return accName;
	}



	public void setAccName(String accName) {
		this.accName = accName;
	}



	public int getAccPin() {
		return accPin;
	}



	public void setAccPin(int accPin) {
		this.accPin = accPin;
	}



	public double getAccBalance() {
		return accBalance;
	}



	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	//To deposit amount
	public double deposit(double amount)
	{
		accBalance=accBalance-amount;
		return accBalance;
	}
	
	//To change the pin
	public int changePin(int newPin) {
		this.accPin=newPin;
		return newPin;
	}
	
	

	public Account(int id) {
		this.accId=id;
	}
	
	public boolean equals(Object ob) {
		if((this.accId)==((Account)ob).accId) {
			return true;
			
		}
		else {
			return false;
		}
	}



	//Abstract method declaration
	abstract public double withdraw(double amount);
	abstract public double calInterest();
	
	//To print the object
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accName=" + accName + ", accPin=" + accPin + ", accBalance=" + accBalance
				+ "]";
	}
	
	
	

}
