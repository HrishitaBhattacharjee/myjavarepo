package com.demo.dao;

import java.util.List;

//Importing packages
import com.demo.bean.*;
import com.demo.exception.*;
public interface AccountDao {
	
	//Method prototype declaration
	void addAccount(Account a);
	Account searchByAccId(int id)throws AccountNotFoundException;
	List<Account> getAllAccounts();
	List<Account> sortData();

}
