package com.demo.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//Importing packages
import com.demo.bean.*;
import com.demo.comparator.MyIdComparator;
import com.demo.exception.*;

public class AccountDaoImpl implements AccountDao{
	
	//Static block
	static {
		alist=new ArrayList<>();
	}
	
	//Instance variables
	static List<Account> alist;
	
	//To add the account to the database
	public void addAccount(Account a) {
		alist.add(a);
	}
	
	//To search an account by its id in the database
	public Account searchByAccId(int id)throws AccountNotFoundException {
		Account acc=null;
		if(id>100 && id<=900) {
			acc=new Savings(id);
		}
		else if(id>900 && id<=2000) {
			acc=new Current(id);
		}
		int pos=alist.indexOf(acc);
		if(pos!=-1) {
			return alist.get(pos);
		}
		
		
		
		throw new AccountNotFoundException("Account not found !");
	}
	public List<Account> getAllAccounts(){
		return alist;
	}
	public List<Account> sortData(){
		Collections.sort(alist, new MyIdComparator());
		return alist;
	}
}
	
